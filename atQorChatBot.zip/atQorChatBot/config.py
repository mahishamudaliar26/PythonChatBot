# config.py
import os

class DefaultConfig:
    """ Bot Configuration """

    PORT = 3978
    APP_ID = os.environ.get("MicrosoftAppId", "e524779e-1972-4bdd-b754-cb0486ee4c93")
    APP_PASSWORD = os.environ.get("MicrosoftAppPassword", "1Tp8Q~yOoZnqDifoj6EvFXB.JGVl-.bp2cFrjal2")
    APP_TYPE = os.environ.get("MicrosoftAppType", "MultiTenent")
    
    AZURE_OPENAI_API_KEY = "f23b85a218244d8e991d7ecd5e83b47c"
    AZURE_OPENAI_API_ENDPOINT = "https://azureopenaiatqoeteamintegration.openai.azure.com/"
    AZURE_OPENAI_MODEL = "gpt-35-turbo"
    AZURE_OPENAI_API_VERSION = "2024-02-15-preview"